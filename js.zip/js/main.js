document.addEventListener('DOMContentLoaded', function() {
    
    // --- Vanilla Tilt for Product Cards ---
    VanillaTilt.init(document.querySelectorAll(".product-card"), {
        max: 15,
        speed: 400,
        glare: true,
        "max-glare": 0.2
    });

    // --- Homepage Slider Logic ---
    const slider = document.querySelector('.hero-slider');
    if (slider) {
        const slides = slider.querySelectorAll('.slide');
        const nextBtn = slider.querySelector('.next');
        const prevBtn = slider.querySelector('.prev');
        let currentSlide = 0;
        let slideInterval;

        function showSlide(n) {
            slides.forEach(slide => slide.classList.remove('active'));
            slides[n].classList.add('active');
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }

        function prevSlide() {
            currentSlide = (currentSlide - 1 + slides.length) % slides.length;
            showSlide(currentSlide);
        }

        function startSlideShow() {
            stopSlideShow(); // Clear existing interval
            slideInterval = setInterval(nextSlide, 5000); // Change slide every 5 seconds
        }

        function stopSlideShow() {
            clearInterval(slideInterval);
        }
        
        if (slides.length > 1) {
            nextBtn.addEventListener('click', () => {
                nextSlide();
                startSlideShow(); // Restart interval on manual navigation
            });

            prevBtn.addEventListener('click', () => {
                prevSlide();
                startSlideShow(); // Restart interval
            });
            
            startSlideShow();
        }
    }
});