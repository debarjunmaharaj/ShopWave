<footer>
    <div class="container">
        <?php echo $settings['footer_text']; // It's already been sanitized on input ?>
    </div>
</footer>