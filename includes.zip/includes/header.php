<header>
    <div class="container nav-container">
        <a href="index.php" class="logo">ModernShop</a>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="cart.php">Cart (<?php echo getCartCount(); ?>)</a></li>
                <li><a href="/admin/index.php">Admin</a></li>
            </ul>
        </nav>
    </div>
</header>