<?php
require_once 'auth_check.php';

// Fetch all settings
$stmt = $pdo->query("SELECT * FROM settings");
$settings_from_db = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $key => $value) {
        $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
        $stmt->execute([$value, $key]);
    }
    // Clear session settings to force a reload on the next page load
    unset($_SESSION['settings']);
    header('Location: settings.php?success=1');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Site Settings</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include 'includes/admin_header.php'; ?>
    <main class="admin-container">
        <h1>Site Settings</h1>

        <?php if (isset($_GET['success'])): ?>
            <p class="success-message">Settings saved successfully!</p>
        <?php endif; ?>

        <div class="form-container">
            <form action="settings.php" method="post">
                <h2>General Settings</h2>
                <div class="form-group">
                    <label>Currency Symbol</label>
                    <input type="text" name="currency_symbol" value="<?php echo htmlspecialchars($settings_from_db['currency_symbol'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Currency Code (e.g., USD, EUR)</label>
                    <input type="text" name="currency_code" value="<?php echo htmlspecialchars($settings_from_db['currency_code'] ?? ''); ?>">
                </div>

                <h2>Homepage Hero Section</h2>
                <div class="form-group">
                    <label>Hero Title</label>
                    <input type="text" name="hero_title" value="<?php echo htmlspecialchars($settings_from_db['hero_title'] ?? ''); ?>">
                </div>
                 <div class="form-group">
                    <label>Hero Subtitle</label>
                    <input type="text" name="hero_subtitle" value="<?php echo htmlspecialchars($settings_from_db['hero_subtitle'] ?? ''); ?>">
                </div>

                <h2>Footer</h2>
                 <div class="form-group">
                    <label>Footer Content (HTML is allowed)</label>
                    <textarea name="footer_text" rows="5"><?php echo htmlspecialchars($settings_from_db['footer_text'] ?? ''); ?></textarea>
                </div>
                
                <button type="submit" class="btn">Save Settings</button>
            </form>
        </div>
    </main>
</body>
</html>