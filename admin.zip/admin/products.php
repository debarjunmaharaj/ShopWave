<?php
require_once 'auth_check.php';

// Handle Add/Edit/Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $product_id = $_POST['product_id'] ?? null;
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $category = $_POST['category'];

    if ($action === 'add' || $action === 'edit') {
        $image_name = $_POST['current_image'] ?? '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target_dir = "../uploads/";
            $image_name = basename($_FILES["image"]["name"]);
            $target_file = $target_dir . $image_name;
            move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
        }

        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO products (name, description, price, stock, category, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $description, $price, $stock, $category, $image_name]);
        } else {
            $stmt = $pdo->prepare("UPDATE products SET name=?, description=?, price=?, stock=?, category=?, image=? WHERE id=?");
            $stmt->execute([$name, $description, $price, $stock, $category, $image_name, $product_id]);
        }
    }
    header('Location: products.php');
    exit;
}

if(isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header('Location: products.php');
    exit;
}

$edit_product = null;
if(isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $edit_product = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include 'includes/admin_header.php'; ?>
    <main class="admin-container">
        <h1>Manage Products</h1>
        
        <!-- Add/Edit Form -->
        <div class="form-container">
            <h2><?php echo $edit_product ? 'Edit Product' : 'Add New Product'; ?></h2>
            <form action="products.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="<?php echo $edit_product ? 'edit' : 'add'; ?>">
                <?php if ($edit_product): ?>
                    <input type="hidden" name="product_id" value="<?php echo $edit_product['id']; ?>">
                    <input type="hidden" name="current_image" value="<?php echo $edit_product['image']; ?>">
                <?php endif; ?>
                
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" value="<?php echo $edit_product['name'] ?? ''; ?>" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" required><?php echo $edit_product['description'] ?? ''; ?></textarea>
                </div>
                <div class="form-group">
                    <label>Price</label>
                    <input type="number" step="0.01" name="price" value="<?php echo $edit_product['price'] ?? ''; ?>" required>
                </div>
                 <div class="form-group">
                    <label>Stock</label>
                    <input type="number" name="stock" value="<?php echo $edit_product['stock'] ?? '1'; ?>" required>
                </div>
                 <div class="form-group">
                    <label>Category</label>
                    <input type="text" name="category" value="<?php echo $edit_product['category'] ?? 'Uncategorized'; ?>" required>
                </div>
                <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="image" accept="image/*">
                    <?php if ($edit_product && $edit_product['image']): ?>
                        <p>Current: <img src="../uploads/<?php echo $edit_product['image']; ?>" width="50"></p>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn"><?php echo $edit_product ? 'Update Product' : 'Add Product'; ?></button>
                 <?php if ($edit_product): ?>
                    <a href="products.php" class="btn btn-secondary">Cancel Edit</a>
                <?php endif; ?>
            </form>
        </div>

        <!-- Products Table -->
        <h2>All Products</h2>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
                while ($product = $stmt->fetch()) {
                    echo "<tr>";
                    echo "<td>{$product['id']}</td>";
                    echo "<td><img src='../uploads/{$product['image']}' width='50'></td>";
                    echo "<td>" . htmlspecialchars($product['name']) . "</td>";
                    echo "<td>$" . htmlspecialchars($product['price']) . "</td>";
                    echo "<td>" . htmlspecialchars($product['stock']) . "</td>";
                    echo "<td>
                            <a href='products.php?action=edit&id={$product['id']}'>Edit</a> | 
                            <a href='products.php?action=delete&id={$product['id']}' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </main>
</body>
</html>