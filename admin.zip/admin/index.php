<?php
require_once 'auth_check.php';

// Stats
$pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
$total_revenue = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE status = 'Delivered'")->fetchColumn();
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include 'includes/admin_header.php'; ?>
    <main class="admin-container">
        <h1>Dashboard</h1>
        <div class="dashboard-stats">
            <div class="stat-card">
                <h2><?php echo $pending_orders; ?></h2>
                <p>Pending Orders</p>
            </div>
            <div class="stat-card">
                <h2>$<?php echo number_format($total_revenue ?? 0, 2); ?></h2>
                <p>Total Revenue (from Delivered)</p>
            </div>
            <div class="stat-card">
                <h2><?php echo $total_products; ?></h2>
                <p>Total Products</p>
            </div>
        </div>
    </main>
</body>
</html>