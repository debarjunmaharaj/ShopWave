<?php
require_once 'auth_check.php';

// Handle image upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['slider_image'])) {
    if ($_FILES['slider_image']['error'] == 0) {
        $target_dir = "../uploads/slider/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0775, true);
        }
        $image_name = time() . '_' . basename($_FILES["slider_image"]["name"]);
        $target_file = $target_dir . $image_name;
        
        if (move_uploaded_file($_FILES["slider_image"]["tmp_name"], $target_file)) {
            $stmt = $pdo->prepare("INSERT INTO slider_images (image_file) VALUES (?)");
            $stmt->execute([$image_name]);
        }
    }
    header('Location: slider.php');
    exit;
}

// Handle image deletion
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT image_file FROM slider_images WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $image = $stmt->fetchColumn();
    
    if ($image && file_exists("../uploads/slider/" . $image)) {
        unlink("../uploads/slider/" . $image);
    }
    
    $delete_stmt = $pdo->prepare("DELETE FROM slider_images WHERE id = ?");
    $delete_stmt->execute([$_GET['id']]);
    header('Location: slider.php');
    exit;
}

$slides = $pdo->query("SELECT * FROM slider_images ORDER BY sort_order ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Slider</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include 'includes/admin_header.php'; ?>
    <main class="admin-container">
        <h1>Manage Homepage Slider</h1>

        <div class="form-container">
            <h2>Add New Slide</h2>
            <form action="slider.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Image (Recommended size: 1600x600 pixels)</label>
                    <input type="file" name="slider_image" accept="image/*" required>
                </div>
                <button type="submit" class="btn">Upload Slide</button>
            </form>
        </div>

        <h2>Current Slides</h2>
        <div class="slider-previews">
            <?php foreach ($slides as $slide): ?>
            <div class="slide-preview">
                <img src="../uploads/slider/<?php echo htmlspecialchars($slide['image_file']); ?>" alt="Slider image">
                <a href="slider.php?action=delete&id=<?php echo $slide['id']; ?>" onclick="return confirm('Are you sure?')" class="delete-slide-btn">Delete</a>
            </div>
            <?php endforeach; ?>
             <?php if (empty($slides)): ?>
                <p>No slides have been uploaded yet.</p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>